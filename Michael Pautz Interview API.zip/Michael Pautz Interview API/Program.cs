﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace Michael_Pautz_Interview_API
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            using (HttpClient client = new HttpClient()) 
            {
                HttpResponseMessage response = await client.GetAsync("https://4c9baa0f-7c69-4e96-9b24-4589c1231f12.mock.pstmn.io/inventoryfeed");
                string data = await response.Content.ReadAsStringAsync();
                var array = JsonSerializer.Deserialize<Dictionary<string, object>[]>(data);
                LessAvailable(array);
                Console.ReadLine();
            }
        }

        public static void LessAvailable(Array arr)
        {
            foreach (Dictionary<string, string> dictionary in arr)
            {
                if (int.Parse(dictionary.qtyavailable) < dictionary.qtysold)
                {
                    Console.WriteLine(dictionary);
                }
            }
        }

        public static void Required(Array arr)
        {
            foreach (var dictionary in arr)
            {
                if (((dictionary.qtysold<=(dictionary.qtyavailable+dictionary.qtyavailable*0.25))&& (dictionary.qtysold >= (dictionary.qtyavailable - dictionary.qtyavailable * 0.25))) || ((dictionary.qtyavailable <= (dictionary.qtysold + dictionary.qtysold * 0.25)) && (dictionary.qtyavailable >= (dictionary.qtysold - dictionary.qtysold * 0.25))))
                {
                    Console.WriteLine(dictionary);
                }
            }
        }

        public static void DeadStock(Array arr)
        {
            foreach (var dictionary in arr)
            {
                if (dictionary.qtysold < (dictionary.qtyavailable * 0.05);
                {
                    Console.WriteLine();
                }
            }
        }
    }
}
